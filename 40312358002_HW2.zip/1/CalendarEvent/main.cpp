#include "calendar.hpp"
#include <chrono>
#include <thread>

int main() {
    Calendar myCalendar;

    // Get current time
    auto now = std::chrono::system_clock::now();
    auto hour = std::chrono::hours(1);

    // Create some events
    Event event1("Meeting with Sam", now + hour, now + 2 * hour);         // Future event
    Event event2("Coffee Break", now + 2 * hour, now + 3 * hour);           // Future event
    Event event3("Past Event", now - 2 * hour, now - hour);                // Past event

    // Add events to the calendar
    myCalendar.addEvent(event1);
    myCalendar.addEvent(event2);
    myCalendar.addEvent(event3);

    // Refresh the calendar
    myCalendar.refresh();

    // Check how many events are left
    std::cout << "Number of events after refresh: " << myCalendar.eventList.size() << std::endl;

    return 0;
}