#include "calendar.hpp"
#include <algorithm>  // Required for std::remove_if

// Add event implementation
void Calendar::addEvent(const Event& event) {
    // Check for conflicts before adding
    for (const auto& existingEvent : eventList) {
        if (event.conflictsWith(existingEvent)) {
            std::cout << "Event conflicts with existing event: " << existingEvent.eventName << std::endl;
            return; // Do not add if conflict exists
        }
    }
    eventList.push_back(event);
    std::cout << "Event added: " << event.eventName << std::endl;
}

// Refresh implementation
void Calendar::refresh() {
    auto currentTime = std::chrono::system_clock::now();
    // Use remove_if to find and erase expired events
    eventList.erase(std::remove_if(eventList.begin(), eventList.end(),
                                   [currentTime](const Event& event) {
                                       return event.endTime < currentTime;
                                   }),
                    eventList.end());
    std::cout << "Calendar refreshed. Expired events removed." << std::endl;
}