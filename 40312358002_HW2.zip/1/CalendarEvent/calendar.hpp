#ifndef CALENDAR_HPP
#define CALENDAR_HPP

#include <iostream>
#include <vector>
#include "event.hpp"

class Calendar {
public:
    std::vector<Event> eventList;

    // Add an event to the calendar
    void addEvent(const Event& event);

    // Refresh the calendar to remove expired events
    void refresh();
};

#endif