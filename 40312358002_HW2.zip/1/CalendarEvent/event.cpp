#include "event.hpp"

// Constructor implementation
Event::Event(const std::string& name, std::chrono::system_clock::time_point start, std::chrono::system_clock::time_point end)
    : eventName(name), startTime(start), endTime(end) {}

// Destructor implementation
Event::~Event() {
    std::cout << "Event deleted: " << eventName << std::endl;
}

// Conflict check implementation
bool Event::conflictsWith(const Event& other) const {
    return (startTime < other.endTime && endTime > other.startTime);
}