#ifndef EVENT_HPP
#define EVENT_HPP

#include <iostream>
#include <string>
#include <chrono>

class Event {
public:
    std::string eventName;
    std::chrono::system_clock::time_point startTime;
    std::chrono::system_clock::time_point endTime;

    // Constructor
    Event(const std::string& name, std::chrono::system_clock::time_point start, std::chrono::system_clock::time_point end);

    // Destructor
    ~Event();

    // Check for conflicts with another event
    bool conflictsWith(const Event& other) const;
};

#endif