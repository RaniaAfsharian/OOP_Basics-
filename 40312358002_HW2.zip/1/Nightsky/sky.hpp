#ifndef SKY_HPP
#define SKY_HPP

#include "star.hpp"
#include <vector>
#include <raylib.h>

class Sky {
public:
    Sky(int width, int height);
    void addStar(const Star& star);
    void draw() const;

private:
    std::vector<Star> stars;
    int width;
    int height;
};

#endif