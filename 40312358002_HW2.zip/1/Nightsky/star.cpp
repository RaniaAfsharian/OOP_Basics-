#include "star.hpp"

Star::Star(int x, int y, float brightness) : x(x), y(y), brightness(brightness) {}

int Star::getX() const {
    return x;
}

int Star::getY() const {
    return y;
}

float Star::getBrightness() const {
    return brightness;
}