#ifndef STAR_HPP
#define STAR_HPP

class Star {
public:
    Star(int x, int y, float brightness);
    int getX() const;
    int getY() const;
    float getBrightness() const;

private:
    int x;
    int y;
    float brightness; // 0.0 to 1.0
};

#endif