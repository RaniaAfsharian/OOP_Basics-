#include "star.hpp"
#include "sky.hpp"
#include <iostream>
#include <raylib.h>

int main() {
    // Initialization
    const int screenWidth = 800;
    const int screenHeight = 450;

    InitWindow(screenWidth, screenHeight, "Night Sky");

    Sky nightSky(screenWidth, screenHeight);

    // Generate some stars
    for (int i = 0; i < 100; ++i) {
        int x = GetRandomValue(0, screenWidth);
        int y = GetRandomValue(0, screenHeight);
        float brightness = GetRandomValue(50, 255) / 255.0f; // Brightness between 0.2 and 1.0
        nightSky.addStar(Star(x, y, brightness));
    }

    SetTargetFPS(60);

    // Main game loop
    while (!WindowShouldClose())    // Detect window close button or ESC key
    {
        // Update
        // TODO: Update your variables here

        // Draw
        BeginDrawing();

        ClearBackground(BLACK);

        nightSky.draw();

        DrawText("Night Sky Simulation", 10, 10, 20, WHITE);

        EndDrawing();
    }

    // De-Initialization
    CloseWindow();        // Close window and OpenGL context

    return 0;
}