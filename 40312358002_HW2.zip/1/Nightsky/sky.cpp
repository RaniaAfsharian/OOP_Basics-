#include "sky.hpp"

Sky::Sky(int width, int height) : width(width), height(height) {}

void Sky::addStar(const Star& star) {
    stars.push_back(star);
}

void Sky::draw() const {
    for (const auto& star : stars) {
        float brightness = star.getBrightness();
        Color color = Color{255, 255, 255, static_cast<unsigned char>(brightness * 255)}; // White with varying alpha
        DrawPixel(star.getX(), star.getY(), color);
    }
}