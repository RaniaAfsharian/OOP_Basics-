#include "patient.hpp"
#include <iostream>
#include <stdexcept>

Patient::Patient(double bodyTemperature, int heartRate, int respiratoryRate, int age, int bloodPressure)
    : bodyTemperature(bodyTemperature), heartRate(heartRate), respiratoryRate(respiratoryRate), bloodPressure(bloodPressure), age(age) {
    if (!validateVitalSigns(bodyTemperature, heartRate, respiratoryRate, age, bloodPressure)) {
        throw std::invalid_argument("Invalid vital signs");
    }
    std::string patientData = "Body Temperature: " + std::to_string(bodyTemperature) +
                              ", Heart Rate: " + std::to_string(heartRate) +
                              ", Respiratory Rate: " + std::to_string(respiratoryRate) +
                              ", Blood Pressure: " + std::to_string(bloodPressure);
    encryptedData = encryptData(patientData);
    std::cout << "Patient created with valid vital signs." << std::endl;
}

Patient::~Patient() {
    std::cout << "Patient data destroyed." << std::endl;
}

double Patient::getBodyTemperature() const {
    return bodyTemperature;
}

int Patient::getHeartRate() const {
    return heartRate;
}

int Patient::getRespiratoryRate() const {
    return respiratoryRate;
}

int Patient::getBloodPressure() const {
    return bloodPressure;
}

bool Patient::validateVitalSigns(double bodyTemperature, int heartRate, int respiratoryRate, int age, int bloodPressure) {
    if (bodyTemperature < 36.0 || bodyTemperature > 37.5) {
        std::cerr << "Invalid body temperature: " << bodyTemperature << std::endl;
        return false;
    }
    if (heartRate < 60 || heartRate > 100) {
        std::cerr << "Invalid heart rate: " << heartRate << std::endl;
        return false;
    }

    // Age-based respiratory rate validation
    int minResRate, maxResRate;
    if (age <= 1) {
        minResRate = 30;
        maxResRate = 60;
    } else if (age <= 3) {
        minResRate = 24;
        maxResRate = 40;
    } else if (age <= 6) {
        minResRate = 22;
        maxResRate = 34;
    } else if (age <= 12) {
        minResRate = 18;
        maxResRate = 30;
    } else if (age <= 18) {
        minResRate = 12;
        maxResRate = 16;
    } else {
        minResRate = 16;
        maxResRate = 20;
    }

    if (respiratoryRate < minResRate || respiratoryRate > maxResRate) {
        std::cerr << "Invalid respiratory rate: " << respiratoryRate << " for age: " << age << std::endl;
        return false;
    }

    if (bloodPressure < 80 || bloodPressure > 120) {
        std::cerr << "Invalid blood pressure: " << bloodPressure << std::endl;
        return false;
    }

    return true;
}

std::string Patient::encryptData(const std::string& data) {
    std::string encryptedData = data;
    char key = 'K';
    for (size_t i = 0; i < encryptedData.size(); ++i) {
        encryptedData[i] = encryptedData[i] ^ key;
    }
    return encryptedData;
}

std::string Patient::decryptData(const std::string& encryptedData) {
    std::string decryptedData = encryptedData;
    char key = 'K';
    for (size_t i = 0; i < decryptedData.size(); ++i) {
        decryptedData[i] = decryptedData[i] ^ key;
    }
    return decryptedData;
}