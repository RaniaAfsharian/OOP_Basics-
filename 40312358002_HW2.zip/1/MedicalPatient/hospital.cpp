#include "hospital.hpp"
#include <iostream>
#include <algorithm>

Hospital::Hospital() {}

Hospital::~Hospital() {}

void Hospital::addPatient(Patient&& patient) {
    patients.push_back(std::move(patient));
}

void Hospital::addPatient(const Patient& patient) {
    patients.push_back(patient);
}

void Hospital::removePatient(int patientIndex) {
    if (patientIndex >= 0 && static_cast<size_t>(patientIndex) < patients.size()) {
        patients.erase(patients.begin() + patientIndex);
        std::cout << "Patient removed successfully." << std::endl;
    } else {
        throw std::out_of_range("Invalid patient index: " + std::to_string(patientIndex));
    }
}

Patient& Hospital::getPatient(int patientIndex) {
    if (patientIndex >= 0 && static_cast<size_t>(patientIndex) < patients.size()) {
        return patients[patientIndex];
    }
    throw std::out_of_range("Invalid patient index: " + std::to_string(patientIndex));
}

void Hospital::listPatients() const {
    std::cout << "Patients in the hospital:" << std::endl;
    if (patients.empty()) {
        std::cout << "No patients in the hospital." << std::endl;
        return;
    }
    for (size_t i = 0; i < patients.size(); ++i) {
        const auto& patient = patients[i];
        std::cout << "- Patient " << i << ":\n";
        std::cout << "  Body Temperature: " << patient.getBodyTemperature() << " °C\n";
        std::cout << "  Heart Rate: " << patient.getHeartRate() << " bpm\n";
        std::cout << "  Respiratory Rate: " << patient.getRespiratoryRate() << " breaths/min\n";
        std::cout << "  Blood Pressure: " << patient.getBloodPressure() << " mmHg\n";
    }
}