#include "patient.hpp"
#include "hospital.hpp"
#include <iostream>

int main() {
    try {
        // Create a hospital
        Hospital myHospital;

        // Create some patients
        Patient patient1(36.6, 75, 16, 25, 120);
        Patient patient2(37.0, 80, 18, 35, 110);

        // Add patients to the hospital
        myHospital.addPatient(std::move(patient1));
        myHospital.addPatient(std::move(patient2));

        // List patients in the hospital
        myHospital.listPatients();

        // Get a patient from the hospital
        Patient& retrievedPatient = myHospital.getPatient(0);
        std::cout << "\nRetrieved patient info:\n";
        std::cout << "Body Temperature: " << retrievedPatient.getBodyTemperature() << " °C\n";
        std::cout << "Heart Rate: " << retrievedPatient.getHeartRate() << " bpm\n";
        std::cout << "Respiratory Rate: " << retrievedPatient.getRespiratoryRate() << " breaths/min\n";
        std::cout << "Blood Pressure: " << retrievedPatient.getBloodPressure() << " mmHg\n";

        // Remove a patient from the hospital
        myHospital.removePatient(1);

        // List patients again to see the changes
        std::cout << "\nPatients after removing patient:\n";
        myHospital.listPatients();
    } catch (const std::exception& e) {
        std::cerr << "Exception caught: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}