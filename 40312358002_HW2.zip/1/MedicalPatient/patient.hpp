#ifndef PATIENT_HPP
#define PATIENT_HPP

#include <iostream>
#include <string>

class Patient {
public:
    Patient(double bodyTemperature, int heartRate, int respiratoryRate, int age, int bloodPressure);
    ~Patient();

    double getBodyTemperature() const;
    int getHeartRate() const;
    int getRespiratoryRate() const;
    int getBloodPressure() const;

private:
    double bodyTemperature;
    int heartRate;
    int respiratoryRate;
    int bloodPressure;
    int age;
    std::string encryptedData;

    bool validateVitalSigns(double bodyTemperature, int heartRate, int respiratoryRate, int age, int bloodPressure);
    std::string encryptData(const std::string& data);
    std::string decryptData(const std::string& encryptedData);
};

#endif