#ifndef HOSPITAL_HPP
#define HOSPITAL_HPP

#include <vector>
#include <string>
#include "patient.hpp"

class Hospital {
public:
    Hospital();
    ~Hospital();

    void addPatient(Patient&& patient); // اضافه کردن نسخه move
    void addPatient(const Patient& patient); // نگه داشتن نسخه کپی برای سازگاری
    void removePatient(int patientIndex);
    Patient& getPatient(int patientIndex); // تغییر به مرجع
    void listPatients() const;

private:
    std::vector<Patient> patients;
};

#endif