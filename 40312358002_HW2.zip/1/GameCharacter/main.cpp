#include "character.hpp"
#include "game.hpp"
#include <iostream>

int main() {
    try {
        // Create some characters
        Character hero("Hero", 100, 20);
        hero.addSkill("Spell word", 15);
        hero.addSkill("Jomoing", 5);

        Character loser("Loser", 150, 30);
        loser.addSkill("Drawing", 20);
        loser.addSkill("Running", 10);

        // Create a game
        Game myGame;

        // Add characters to the game
        myGame.addCharacter(std::move(hero));  
        myGame.addCharacter(std::move(loser));

        // List characters in the game
        myGame.listCharacters();

        // Get a character from the game
        Character& retrievedHero = myGame.getCharacter("Hero");
        Character& retrievedLoser = myGame.getCharacter("Loser");
        std::cout << "\nRetrieved character info:\n";
        retrievedHero.displayCharacterInfo();
        retrievedLoser.displayCharacterInfo();

        // Remove a character from the game
        myGame.removeCharacter("Loser");

        // List characters again to see the changes
        std::cout << "\nCharacters after removing Loser:\n";
        myGame.listCharacters();
    }
    catch (const std::runtime_error& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}