#ifndef CHARACTER_HPP
#define CHARACTER_HPP

#include <iostream>
#include <map>
#include <string>

class Character {
public:
    Character(const std::string& name, int health, int power);
    ~Character() = default;

    std::string getName() const;
    int getHealth() const;
    int getPower() const;
    int getSkillLevel(const std::string& skillName) const;

    void setName(const std::string& name);
    void setHealth(int health);
    void setPower(int power);
    void addSkill(const std::string& skillName, int level);
    void removeSkill(const std::string& skillName);

    void displayCharacterInfo() const;

private:
    std::string name;
    int health;
    int power;
    std::map<std::string, int> skills; // skill name, skill level
};

#endif