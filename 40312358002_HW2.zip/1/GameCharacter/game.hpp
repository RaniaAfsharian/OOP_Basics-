#ifndef GAME_HPP
#define GAME_HPP

#include <vector>
#include <string>
#include "character.hpp"

class Game {
public:
    Game();
    ~Game();

    void addCharacter(Character&& character); 
    void addCharacter(const Character& character); // نگه داشتن نسخه کپی برای سازگاری
    void removeCharacter(const std::string& characterName);
    Character& getCharacter(const std::string& characterName); // تغییر به مرجع
    void listCharacters() const;

private:
    std::vector<Character> characters;
};

#endif