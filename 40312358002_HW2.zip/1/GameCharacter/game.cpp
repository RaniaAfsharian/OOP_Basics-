#include "game.hpp"
#include <iostream>
#include <algorithm>

Game::Game() {}

Game::~Game() {}

void Game::addCharacter(Character&& character) {
    characters.push_back(std::move(character));
}

void Game::addCharacter(const Character& character) {
    characters.push_back(character);
}

void Game::removeCharacter(const std::string& characterName) {
    auto initialSize = characters.size();
    characters.erase(
        std::remove_if(characters.begin(), characters.end(),
                       [&characterName](const Character& character) {
                           return character.getName() == characterName;
                       }),
        characters.end()
    );
    if (characters.size() == initialSize) {
        std::cout << "Character " << characterName << " not found." << std::endl;
    }
}

Character& Game::getCharacter(const std::string& characterName) {
    for (auto& character : characters) {
        if (character.getName() == characterName) {
            return character;
        }
    }
    throw std::runtime_error("Character " + characterName + " not found.");
}

void Game::listCharacters() const {
    std::cout << "Characters in the game:" << std::endl;
    if (characters.empty()) {
        std::cout << "No characters in the game." << std::endl;
        return;
    }
    for (const auto& character : characters) {
        std::cout << "- " << character.getName() << std::endl;
    }
}