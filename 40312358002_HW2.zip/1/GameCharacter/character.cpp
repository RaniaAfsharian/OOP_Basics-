#include "character.hpp"
#include <iostream>

Character::Character(const std::string& name, int health, int power)
    : name(name), health(health), power(power) {}

std::string Character::getName() const {
    return name;
}

int Character::getHealth() const {
    return health;
}

int Character::getPower() const {
    return power;
}

int Character::getSkillLevel(const std::string& skillName) const {
    auto it = skills.find(skillName);
    if (it != skills.end()) {
        return it->second;
    } else {
        return 0; // Or some other default value indicating the skill is not present
    }
}

void Character::setName(const std::string& name) {
    this->name = name;
}

void Character::setHealth(int health) {
    this->health = health;
}

void Character::setPower(int power) {
    this->power = power;
}

void Character::addSkill(const std::string& skillName, int level) {
    skills[skillName] = level;
}

void Character::removeSkill(const std::string& skillName) {
    skills.erase(skillName);
}

void Character::displayCharacterInfo() const {
    std::cout << "Name: " << name << std::endl;
    std::cout << "Health: " << health << std::endl;
    std::cout << "Power: " << power << std::endl;
    std::cout << "Skills:" << std::endl;
    for (const auto& skill : skills) {
        std::cout << "  " << skill.first << ": " << skill.second << std::endl;
    }
}