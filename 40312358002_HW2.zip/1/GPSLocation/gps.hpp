#ifndef GPS_HPP
#define GPS_HPP

#include <iostream>
#include <stdexcept>
#include <string>

class GPS {
public:
    GPS(double latitude, double longitude, const std::string& locationName = "");
    ~GPS();

    double getLatitude() const;
    double getLongitude() const;
    std::string getLocationName() const;

private:
    double latitude;
    double longitude;
    std::string locationName;
};

#endif