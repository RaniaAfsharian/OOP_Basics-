#include "gps.hpp"
#include <iostream>
#include <stdexcept>

GPS::GPS(double latitude, double longitude, const std::string& locationName)
    : latitude(latitude), longitude(longitude), locationName(locationName) {
    if (latitude < -90.0 || latitude > 90.0) {
        throw std::invalid_argument("Latitude is invalid");
    }
    if (longitude < -180.0 || longitude > 180.0) {
        throw std::invalid_argument("Longitude is invalid");
    }
    std::cout << "GPS object constructed with valid coordinates for "
              << (locationName.empty() ? "unnamed location" : locationName) << std::endl;
}

GPS::~GPS() {
    std::cout << "Last known position - "
              << (locationName.empty() ? "Unnamed Location" : locationName)
              << ": Latitude: " << latitude
              << ", Longitude: " << longitude << std::endl;
}

double GPS::getLatitude() const {
    return latitude;
}

double GPS::getLongitude() const {
    return longitude;
}

std::string GPS::getLocationName() const {
    return locationName;
}