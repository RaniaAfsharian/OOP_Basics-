#include "gps.hpp"
#include <iostream>

int main() {
    try {
        GPS tehran(35.6892, 51.3890, "Tehran, Iran");
        std::cout << "Location: " << tehran.getLocationName() << std::endl;
        std::cout << "Latitude: " << tehran.getLatitude() << std::endl;
        std::cout << "Longitude: " << tehran.getLongitude() << std::endl;

        GPS hamedan(34.7992, 48.5146, "Hamedan, Iran");
        std::cout << "Location: " << hamedan.getLocationName() << std::endl;
        std::cout << "Latitude: " << hamedan.getLatitude() << std::endl;
        std::cout << "Longitude: " << hamedan.getLongitude() << std::endl;

        GPS invalidLocation(100.0, 200.0, "Invalid Location"); // Invalid coordinates
    } catch (const std::invalid_argument& e) {
        std::cerr << "Exception caught: " << e.what() << std::endl;
    }

    return 0;
}